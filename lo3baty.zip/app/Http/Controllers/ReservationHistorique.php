<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReservationHistorique extends Controller
{
    //
}
