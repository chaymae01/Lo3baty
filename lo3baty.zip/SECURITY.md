# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| Main Version  | ✅         |
| Other Branches   | ❌         |

## Reporting a Vulnerability

If you find a security issue or a data leak, please email us lo3baty1@gmail.com

Do not open a public GitHub issue. We will reply as soon as we can.
