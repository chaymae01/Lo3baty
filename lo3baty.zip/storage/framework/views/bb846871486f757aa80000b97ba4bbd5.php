

<?php $__env->startSection('content'); ?>
    

        <!-- Main -->
        <main id="dashboard-content" class="flex-1 p-8 overflow-y-auto">
            <div class="p-8 bg-gray-100 min-h-screen">
                <h1 class="text-2xl font-bold mb-6">Choisir un objet</h1>

                <?php if($objets->isEmpty()): ?>
                    <p class="text-gray-500">Aucun objet à afficher.</p>
                <?php else: ?>
                    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php $__currentLoopData = $objets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="bg-white rounded-xl shadow p-4 hover:shadow-lg transition">
                                    <img src="<?php echo e($objet->images->first()
                            ? asset('storage/' . $objet->images->first()->url)
                            : 'https://via.placeholder.com/300x200?text=Aucune+image'); ?>" alt="Image"
                                        class="w-full h-32 object-cover rounded mb-3">

                                    <p class="font-semibold mb-2"><?php echo e($objet->nom); ?></p>

                                    <a href="<?php echo e(route('annonce.create', $objet)); ?>"
                                        class="bg-indigo-600 text-white px-3 py-1 rounded text-sm hover:bg-indigo-700">
                                        Créer une annonce
                                    </a>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/annonces/choose.blade.php ENDPATH**/ ?>