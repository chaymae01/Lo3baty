<svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" stroke-width="2"
     viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round"
          d="M20 12l-8 4.5L4 12m16-4.5l-8-4.5L4 7.5M12 3v13.5"/>
</svg>
<?php /**PATH C:\wamp64\www\laravelWeb\resources\views/components/icons/cube.blade.php ENDPATH**/ ?>