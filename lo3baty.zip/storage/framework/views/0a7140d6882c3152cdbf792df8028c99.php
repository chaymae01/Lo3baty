<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">
    <!-- Sidebar fixe à gauche -->
    <div class="w-64 fixed top-0 left-0 bottom-0 bg-white shadow-md z-10">
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Contenu principal à droite avec une marge à gauche pour la sidebar -->
    <div class="flex-1 ml-64 p-8 space-y-6">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl font-bold text-gray-800">Gestion des Paiements</h1>
            <div class="flex space-x-3">
            <a href="<?php echo e(route('admin.paiements.export', array_merge(request()->query(), ['type' => 'clients']))); ?>"
   class="btn btn-primary">
    <i data-lucide="download" class="w-4 h-4 mr-2"></i> Exporter Clients
</a>
<a href="<?php echo e(route('admin.paiements.export', array_merge(request()->query(), ['type' => 'partenaires']))); ?>"
   class="btn btn-secondary">
    <i data-lucide="download" class="w-4 h-4 mr-2"></i> Exporter Partenaires
</a>
            </div>
        </div>

        <?php echo $__env->make('admin.paiements.partials._stats', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.paiements.partials._filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Section des tables -->
        <div class="space-y-8">
            <!-- Tableau Clients - Conditionnellement visible -->
            <?php if(!request()->has('type') || request('type') === 'clients'): ?>
                <?php echo $__env->make('admin.paiements.partials._client_table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>

            <!-- Tableau Partenaires - Conditionnellement visible -->
            <?php if(!request()->has('type') || request('type') === 'partenaires'): ?>
                <?php echo $__env->make('admin.paiements.partials._partner_table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
            
            <!-- Message si aucun résultat -->
            <?php if((request()->has('type') && $paiementsClients->isEmpty() && $paiementsPartenaires->isEmpty())): ?>
                <div class="bg-white rounded-lg shadow p-6 text-center">
                    <p class="text-gray-500">Aucun résultat trouvé pour les critères de recherche sélectionnés.</p>
                    <a href="<?php echo e(route('admin.paiements')); ?>" class="btn btn-primary mt-4">
                        <i data-lucide="refresh-ccw" class="w-4 h-4 mr-2"></i> Réinitialiser les filtres
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/admin/paiements/index.blade.php ENDPATH**/ ?>