


<?php $__env->startSection('content'); ?>
   

        <!-- Main -->
        <main id="dashboard-content" class="flex-1 p-8 overflow-y-auto">
            <h1 class="text-3xl font-extrabold text-indigo-700 mb-8">🎮 Mes objets à louer</h1>

            <?php if($objets->isEmpty()): ?>
                <p class="text-gray-500 text-lg">Aucun objet trouvé pour l’instant.</p>
            <?php else: ?>
                <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $objets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-xl shadow p-6 hover:shadow-xl transition-all">

                            
                            <?php if($objet->images->isNotEmpty()): ?>
                                <div class="flex gap-2 mb-4 overflow-x-auto">
                                    <?php $__currentLoopData = $objet->images->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('storage/' . $image->url)); ?>" alt="Image de <?php echo e($objet->nom); ?>"
                                            class="w-24 h-24 object-cover rounded border">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div
                                    class="w-full h-48 bg-gray-100 rounded flex items-center justify-center text-gray-400 text-sm mb-4">
                                    Aucune image disponible
                                </div>
                            <?php endif; ?>

                            <h2 class="text-xl font-semibold text-indigo-600"><?php echo e($objet->nom); ?></h2>
                            <p class="text-sm text-gray-600 mt-1 mb-3"><?php echo e(Str::limit($objet->description, 100)); ?></p>

                            <span class="inline-block bg-indigo-100 text-indigo-800 text-xs font-semibold px-3 py-1 rounded-full">
                                <?php echo e(number_format($objet->prix_journalier, 2)); ?> DH / jour
                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/partenaire/objets/index.blade.php ENDPATH**/ ?>