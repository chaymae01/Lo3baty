<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">

    <!-- Sidebar fixe -->
    <div class="flex min-h-screen bg-gray-50">
    <!-- Sidebar fixe à gauche -->
    <div class="w-64 fixed top-0 left-0 bottom-0 bg-white shadow-md z-10">
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Contenu principal avec marge pour la sidebar -->
    <div class="flex-1 p-8 space-y-10 ml-64"> <!-- Ajustez ml-64 selon la largeur de votre sidebar -->
    
    <h1 class="text-2xl font-bold mb-6">Gestion des Commentaires</h1>
    

    <!-- Filtres -->
    <div class="bg-white rounded-lg shadow-md p-4 mb-6">
        <form action="<?php echo e(route('admin.commentaires')); ?>" method="GET" class="flex flex-wrap gap-4">
            <div>
                <label for="statut" class="block text-sm font-medium text-gray-700">Statut</label>
                <select name="statut" id="statut" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                    <option value="">Tous</option>
                    <option value="signale" <?php echo e(request('statut') === 'signale' ? 'selected' : ''); ?>>🚩 Signalé</option>
                    <option value="publie" <?php echo e(request('statut') === 'publie' ? 'selected' : ''); ?>>✅ Publié</option>
                </select>
            </div>
            
            <div>
                <label for="type" class="block text-sm font-medium text-gray-700">Type</label>
                <select name="type" id="type" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                    <option value="">Tous</option>
                    <option value="client_partenaire" <?php echo e(request('type') === 'client_partenaire' ? 'selected' : ''); ?>>Partenaire → Client </option>
                    <option value="partenaire_client" <?php echo e(request('type') === 'partenaire_client' ? 'selected' : ''); ?>>Client → Partenaire</option>
                    <option value="annonce" <?php echo e(request('type') === 'annonce' ? 'selected' : ''); ?>>Évaluation d'annonce</option>
                </select>
            </div>
            
            <div class="self-end">
                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Filtrer
                </button>
                <a href="<?php echo e(route('admin.commentaires')); ?>" class="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Réinitialiser
                </a>
            </div>
        </form>
    </div>

    <!-- Tableau des commentaires -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Auteur</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cible</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commentaire</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $commentaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($commentaire->id); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">
                                    <?php if($commentaire->client): ?>
                                        <?php echo e($commentaire->client->surnom); ?>

                                        <div class="text-xs text-gray-500">(Client)</div>
                                    <?php elseif($commentaire->partner): ?>
                                        <?php echo e($commentaire->partner->surnom); ?>

                                        <div class="text-xs text-gray-500">(Partenaire)</div>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">
                                    <?php if($commentaire instanceof \App\Models\Admin\EvaluationOnClients): ?>
                                        <?php if($commentaire->partner): ?>
                                            <?php echo e($commentaire->partner->surnom); ?>

                                            <div class="text-xs text-gray-500">(Partenaire)</div>
                                        <?php endif; ?>
                                    <?php elseif($commentaire instanceof \App\Models\Admin\EvaluationOnPartners): ?>
                                        <?php if($commentaire->client): ?>
                                            <?php echo e($commentaire->client->surnom); ?>

                                            <div class="text-xs text-gray-500">(Client)</div>
                                        <?php endif; ?>
                                    <?php elseif($commentaire instanceof \App\Models\Admin\EvaluationOnAnnonces): ?>
                                        <?php if($commentaire->objet): ?>
                                            <?php echo e($commentaire->objet->nom); ?>

                                            <div class="text-xs text-gray-500">(Annonce)</div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php if($commentaire instanceof \App\Models\Admin\EvaluationOnClients): ?>
                                     Partenaire → Client
                                <?php elseif($commentaire instanceof \App\Models\Admin\EvaluationOnPartners): ?>
                                    Client → Partenaire
                                <?php else: ?>
                                    Évaluation d'annonce 
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <span class="text-yellow-400">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= $commentaire->note): ?>
                                                ⭐
                                            <?php else: ?>
                                                <span class="text-gray-300">☆</span>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </span>
                                    <span class="ml-1 text-sm text-gray-500">(<?php echo e($commentaire->note); ?>/5)</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-500">
                                <div class="group relative">
                                    <span class="cursor-pointer hover:text-blue-500">
                                        <?php echo e(Str::limit($commentaire->commentaire, 50)); ?>

                                    </span>
                                    <?php if(strlen($commentaire->commentaire) > 50): ?>
                                        <div class="absolute hidden group-hover:block z-10 w-64 p-2 mt-1 text-sm bg-white border rounded shadow-lg">
                                            <?php echo e($commentaire->commentaire); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if($commentaire->flag_reason): ?>
                                    <div class="text-xs text-red-500 mt-1">
                                        <strong>Raison:</strong> <?php echo e($commentaire->flag_reason); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($commentaire->is_flagged): ?>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                        🚩 Signalé
                                    </span>
                                <?php else: ?>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        ✅ Publié
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
    <div class="flex items-center space-x-2">
        <!-- Bouton Voir : redirige vers la page de détail du commentaire -->
        <a href="<?php echo e(route('admin.commentaires.show', $commentaire->id)); ?>" 
           class="px-3 py-1 bg-blue-100 text-blue-800 rounded hover:bg-blue-200">
            Voir
        </a>

        <!-- Si le commentaire est signalé, afficher le bouton de validation -->
        <?php if($commentaire->is_flagged): ?>
            <!-- Bouton Valider : approuve un commentaire signalé -->
            <form action="<?php echo e(route('admin.commentaires.approve', $commentaire->id)); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="px-3 py-1 bg-green-100 text-green-800 rounded hover:bg-green-200">
                    Valider
                </button>
            </form>
        <?php else: ?>
            <!-- 
            Bouton Rejeter (commenté) : prévu pour refuser un commentaire non signalé 
            <form action="<?php echo e(route('admin.commentaires.destroy', $commentaire->id)); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded hover:bg-yellow-200">
                    Rejeter
                </button>
            </form> 
            -->
        <?php endif; ?>

        <!-- Bouton Supprimer : suppression définitive du commentaire -->
        <form action="<?php echo e(route('admin.commentaires.destroy', $commentaire->id)); ?>" method="POST" class="inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="px-3 py-1 bg-red-100 text-red-800 rounded hover:bg-red-200">
                Supprimer
            </button>
        </form>
    </div>
</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-4 text-center text-sm text-gray-500">Aucun commentaire trouvé</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (window.lucide) {
            lucide.createIcons();
        } else {
            console.error("Lucide Icons n'est pas chargé !");
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .group:hover .group-hover\:block {
        display: block;
    }
    tr:hover {
        background-color: #f9fafb;
    }
    .transition-colors {
        transition: color 0.2s, background-color 0.2s;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/admin/commentaires/index.blade.php ENDPATH**/ ?>