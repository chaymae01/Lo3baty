<?php $__env->startSection('title', 'Gestion des Annonces'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex-1 p-6 space-y-6">
        <div class="container mx-auto px-4 py-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Gestion des Annonces</h1>
            </div>

            
            <div class="mb-6 bg-white p-4 rounded-lg shadow">
                <form method="GET" action="<?php echo e(route('admin.annonces.index')); ?>" class="flex items-center space-x-4">
                    <label for="statut" class="text-sm font-medium text-gray-700">Filtrer par statut :</label>
                    <select name="statut" id="statut" onchange="this.form.submit()" 
                            class="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Tous les statuts</option>
                        <?php $__currentLoopData = $statuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($statut); ?>" <?php echo e(request('statut') == $statut ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($statut)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if(request('statut')): ?>
                        <a href="<?php echo e(route('admin.annonces.index')); ?>" 
                           class="text-sm text-gray-600 hover:text-gray-800 ml-2">
                            Réinitialiser
                        </a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">ID</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Objet</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Partenaire</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Prix/J</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Statut</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Premium</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Dates</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e($annonce->id); ?></td>
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e($annonce->objet->nom ?? '-'); ?></td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php echo e($annonce->partenaire->nom ?? '-'); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e(number_format($annonce->prix_journalier, 2)); ?> €</td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <span class="px-2 py-1 text-xs rounded-full 
                                       <?php echo e($annonce->statut === 'active' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'); ?>">
                                       <?php echo e(ucfirst($annonce->statut)); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php if($annonce->premium): ?>
                                        <span class="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                                            <?php echo e($annonce->premium_periode); ?> jours
                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-500">Non</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 border-b border-gray-200 text-sm">
                                    <?php echo e($annonce->date_debut->format('d/m/Y')); ?> - 
                                    <?php echo e($annonce->date_fin->format('d/m/Y')); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <a href="<?php echo e(route('admin.annonces.show', $annonce)); ?>" 
                                       class="text-blue-600 hover:text-blue-900">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-4 px-6 py-3 bg-gray-50 border-t border-gray-200">
                    <?php if(request('statut')): ?>
                        <?php echo e($annonces->appends(['statut' => request('statut')])->links()); ?>

                    <?php else: ?>
                        <?php echo e($annonces->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/Admin/annonces/index.blade.php ENDPATH**/ ?>