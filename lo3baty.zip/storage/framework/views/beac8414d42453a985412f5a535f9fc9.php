<?php $__env->startSection('title', 'Connexion - Lo3baty'); ?> 

<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="w-full max-w-md space-y-8">
        <div class="bg-white p-8 rounded-lg shadow-md">
            <!-- Logo -->
            <div class="flex justify-center mb-6">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('storage/images/Lo3baty.jpg')); ?>" 
                         alt="Lo3baty Logo" 
                         class="h-20 w-auto mx-auto hover:opacity-92 transition-opacity">
                </a>
            </div>

            <div class="text-center">
                <h2 class="mt-2 text-3xl font-bold text-gray-900"><?php echo e(__('Connexion')); ?></h2>
            </div>

            <form class="mt-6 space-y-6" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="space-y-4">
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700"><?php echo e(__('Email')); ?></label>
                        <div class="mt-1">
                            <input id="email" name="email" type="email" autocomplete="email" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-[#e63a28] focus:border-[#e63a28] <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div>
                        <label for="mot_de_passe" class="block text-sm font-medium text-gray-700"><?php echo e(__('Mot de passe')); ?></label>
                        <div class="mt-1">
                            <input id="mot_de_passe" name="mot_de_passe" type="password" autocomplete="current-password" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-[#e63a28] focus:border-[#e63a28] <?php $__errorArgs = ['mot_de_passe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['mot_de_passe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input id="remember" name="remember" type="checkbox"
                               class="h-4 w-4 text-[#e63a28] focus:ring-[#e63a28] border-gray-300 rounded" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="remember" class="ml-2 block text-sm text-gray-900">
                            <?php echo e(__('Se souvenir de moi')); ?>

                        </label>
                    </div>
                </div>

                <div class="space-y-4">
                    <button type="submit"
                            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#e63a28] hover:bg-[#d0311f] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#e63a28] transition-colors">
                        <?php echo e(__('Connexion')); ?>

                    </button>

                    <?php if(Route::has('password.request')): ?>
                        <div class="text-center">
                            <a href="<?php echo e(route('password.request')); ?>" class="text-sm font-medium text-[#e63a28] hover:text-[#d0311f]">
                                <?php echo e(__('Mot de passe oublié?')); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Lo3baty_git\resources\views/auth/login.blade.php ENDPATH**/ ?>