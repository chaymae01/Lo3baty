

<?php $__env->startSection('content'); ?>
<main class="flex-1 p-8 overflow-y-auto bg-gray-50">
    <div class="max-w-6xl mx-auto">

        <h1 class="text-3xl font-bold text-indigo-700 mb-6">📋 Gérer mes annonces</h1>

        <?php if(session('ok')): ?>
            <div class="mb-4 p-4 bg-green-100 text-green-800 rounded shadow">
                <?php echo e(session('ok')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mb-4 p-4 bg-red-100 text-red-800 rounded shadow">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <?php if($annonces->isEmpty()): ?>
            <p class="text-gray-500 text-center text-lg mt-12">Aucune annonce trouvée pour le moment.</p>
        <?php else: ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-xl shadow-md p-4 flex flex-col space-y-3 hover:shadow-lg transition duration-200">

                        <!-- Image -->
                        <img src="<?php echo e($annonce->objet->images->first()
                            ? asset('storage/' . $annonce->objet->images->first()->url)
                            : 'https://via.placeholder.com/300x200?text=Aucune+image'); ?>"
                             alt="Objet"
                             class="w-full h-40 object-cover rounded-lg border">

                        <!-- Titre + Premium -->
                        <div class="flex items-center justify-between">
                            <h2 class="text-lg font-semibold text-gray-800">
                                <?php echo e($annonce->objet->nom); ?>

                            </h2>
                            <?php if($annonce->premium): ?>
                                <span class="text-yellow-500 text-sm font-bold">💎 Premium</span>
                            <?php endif; ?>
                        </div>

                        <!-- Statut -->
                        <span class="inline-block text-sm font-medium px-3 py-1 rounded-full w-fit
                            <?php echo e($annonce->statut === 'active'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-red-100 text-red-700'); ?>">
                            <?php echo e($annonce->statut === 'active' ? '✅ Active' : '🛑 Inactive'); ?>

                        </span>

                        <!-- Coordonnées -->
                        <div class="text-sm text-gray-500">
                            <strong>📍 Adresse :</strong>
                            <span><?php echo e($annonce->adress); ?></span>
                        </div>

                        <!-- Boutons -->
                        <div class="flex flex-col gap-2 pt-2">
                            <?php if($annonce->statut === 'active'): ?>
                                <form action="<?php echo e(route('annonce.archiver', $annonce)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="w-full text-sm text-red-600 border border-red-300 px-4 py-2 rounded hover:bg-red-100 transition">
                                        🗃 Archiver
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('annonce.activer', $annonce)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="w-full text-sm text-green-600 border border-green-300 px-4 py-2 rounded hover:bg-green-100 transition">
                                        ✅ Activer
                                    </button>
                                </form>
                            <?php endif; ?>

                            <a href="<?php echo e(route('annonce.edit', $annonce)); ?>"
                               class="w-full text-sm text-blue-600 border border-blue-300 px-4 py-2 rounded hover:bg-blue-100 text-center transition">
                                ✏️ Modifier
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/annonces/gestion.blade.php ENDPATH**/ ?>