<?php $__env->startSection('title', 'Gestion des reclamations'); ?>
<?php $__env->startSection('content'); ?>

<div class="flex">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex-1 p-6 space-y-6">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-2xl font-bold mb-6">Gestion des Réclamations</h1>

            
            <div class="mb-6 bg-white p-4 rounded-lg shadow">
                <form method="GET" action="<?php echo e(route('admin.reclamations.index')); ?>" class="flex items-center space-x-4">
                    <label for="statut" class="text-sm font-medium text-gray-700">Filtrer par statut :</label>
                    <select name="statut" id="statut" onchange="this.form.submit()" 
                            class="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Tous les statuts</option>
                        <option value="en_attente" <?php echo e(request('statut') == 'en_attente' ? 'selected' : ''); ?>>En attente</option>
                        <option value="resolue" <?php echo e(request('statut') == 'resolue' ? 'selected' : ''); ?>>Resolue</option>
                    </select>
                    <?php if(request('statut')): ?>
                        <a href="<?php echo e(route('admin.reclamations.index')); ?>" 
                           class="text-sm text-gray-600 hover:text-gray-800 ml-2">
                            Réinitialiser
                        </a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">ID</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Utilisateur</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Sujet</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Statut</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Date</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reclamations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reclamation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e($reclamation->id); ?></td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php if($reclamation->utilisateur): ?>
                                        <?php echo e($reclamation->utilisateur->nom); ?>

                                    <?php else: ?>
                                        Utilisateur (ID: <?php echo e($reclamation->client_id); ?>) non trouvé
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e(Str::limit($reclamation->sujet, 50)); ?></td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php
                                        // Conversion du statut pour la comparaison
                                        $statut = str_replace(' ', '_', strtolower($reclamation->statut));
                                        $statut = $statut === 'resolu' ? 'resolue' : $statut;
                                    ?>
                                    <span class="px-2 py-1 text-xs rounded-full 
                                        <?php echo e($statut === 'en_attente' ? 'bg-yellow-100 text-yellow-800' : 
                                           ($statut === 'resolue' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800')); ?>">
                                        <?php echo e(ucfirst(str_replace('_', ' ', $statut))); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php echo e($reclamation->created_at->format('d/m/Y H:i')); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200 space-x-2">
                                    <a href="<?php echo e(route('admin.reclamations.show', $reclamation)); ?>" 
                                       class="text-blue-600 hover:text-blue-900">
                                        <i class="fas fa-eye"></i> Voir
                                    </a>
                                    <?php if($reclamation->piece_jointe): ?>
                                    <a href="<?php echo e(route('admin.reclamations.download', $reclamation)); ?>" 
                                       class="text-purple-600 hover:text-purple-900">
                                        <i class="fas fa-download"></i> Pièce jointe
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-4 px-6 py-3 bg-gray-50 border-t border-gray-200">
                    <?php if(request('statut')): ?>
                        <?php echo e($reclamations->appends(['statut' => request('statut')])->links()); ?>

                    <?php else: ?>
                        <?php echo e($reclamations->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/admin/reclamations/index.blade.php ENDPATH**/ ?>