<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <div class="px-6 py-4 bg-green-600 text-white">
                <h2 class="text-xl font-semibold">Tableau de Bord Partenaire</h2>
            </div>
            
            <div class="p-6">
                <p class="mb-6 text-gray-700">Bienvenue Partenaire, <?php echo e(Auth::user()->name); ?> !</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Vos éléments de dashboard partenaire ici -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/partenaire/home.blade.php ENDPATH**/ ?>