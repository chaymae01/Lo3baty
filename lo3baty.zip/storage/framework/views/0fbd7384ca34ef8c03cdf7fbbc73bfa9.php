<div>
    <label class="block text-sm font-medium mb-1">Nom</label>
    <input type="text" name="nom" value="<?php echo e(old('nom', $product->nom ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
</div>

<div>
    <label class="block text-sm font-medium mb-1">Description</label>
    <textarea name="description" class="w-full border rounded px-3 py-2"><?php echo e(old('description', $product->description ?? '')); ?></textarea>
</div>

<div>
    <label class="block text-sm font-medium mb-1">Ville</label>
    <input type="text" name="ville" value="<?php echo e(old('ville', $product->ville ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
</div>

<div>
    <label class="block text-sm font-medium mb-1">État</label>
    <select name="etat" class="w-full border rounded px-3 py-2" required>
        <option value="">-- Sélectionner l'état --</option>
        <option value="Neuf" <?php echo e(old('etat', $product->etat ?? '') == 'Neuf' ? 'selected' : ''); ?>>Neuf</option>
        <option value="Bon état" <?php echo e(old('etat', $product->etat ?? '') == 'Bon état' ? 'selected' : ''); ?>>Bon état</option>
        <option value="Usage" <?php echo e(old('etat', $product->etat ?? '') == 'Usage' ? 'selected' : ''); ?>>Usé</option>
    </select>
</div>

<div>
    <label class="block text-sm font-medium mb-1">Tranche d'âge</label>
    <select name="tranche_age" class="w-full border rounded px-3 py-2" required>
        <option value="">-- Sélectionner --</option>
        <option value="<3" <?php echo e(old('tranche_age', $product->tranche_age ?? '') == '<3' ? 'selected' : ''); ?>>&lt; 3 ans</option>
        <option value="3-5" <?php echo e(old('tranche_age', $product->tranche_age ?? '') == '3-5' ? 'selected' : ''); ?>>3–5 ans</option>
        <option value="6-8" <?php echo e(old('tranche_age', $product->tranche_age ?? '') == '6-8' ? 'selected' : ''); ?>>6–8 ans</option>
        <option value="9-12" <?php echo e(old('tranche_age', $product->tranche_age ?? '') == '9-12' ? 'selected' : ''); ?>>9–12 ans</option>
        <option value="13+" <?php echo e(old('tranche_age', $product->tranche_age ?? '') == '13+' ? 'selected' : ''); ?>>13 ans et plus</option>
    </select>
</div>


<div>
    <label class="block text-sm font-medium mb-1">Catégorie</label>
    <select name="categorie_id" class="w-full border rounded px-3 py-2" required>
        <option value="">-- Choisir une catégorie --</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categorie->id); ?>" <?php echo e(old('categorie_id', $product->categorie_id ?? '') == $categorie->id ? 'selected' : ''); ?>>
                <?php echo e($categorie->nom); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div>
    <label class="block text-sm font-medium mb-1">Images du produit</label>

    <?php if($product && $product->images->isNotEmpty()): ?>
        <div class="flex flex-wrap gap-3 mb-2">
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative">
                    <img src="<?php echo e(asset('storage/' . $img->url)); ?>" alt="Image actuelle" class="w-24 h-24 object-cover rounded border">
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="text-xs text-gray-500 mt-1">Les nouvelles images s’ajouteront en plus des existantes.</p>
    <?php endif; ?>

    <input type="file" name="images[]" accept="image/*" class="w-full border rounded px-3 py-2" multiple>
    <p class="text-xs text-gray-500 mt-1">Vous pouvez sélectionner plusieurs images.</p>
</div>
<?php /**PATH C:\wamp64\www\Lo3baty_git\resources\views/partenaire/products/_form.blade.php ENDPATH**/ ?>