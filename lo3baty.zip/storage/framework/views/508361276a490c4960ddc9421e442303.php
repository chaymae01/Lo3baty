<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <!-- Total Clients -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-500">Total Clients</p>
                <p class="text-2xl font-bold text-blue-600"><?php echo e(number_format($stats['total_clients'], 2)); ?> DH</p>
            </div>
            <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                <i data-lucide="users" class="w-6 h-6"></i>
            </div>
        </div>
        <p class="mt-2 text-xs text-gray-500"><?php echo e($stats['count_clients']); ?> transactions</p>
    </div>

    <!-- Total Partenaires -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-500">Total Partenaires</p>
                <p class="text-2xl font-bold text-purple-600"><?php echo e(number_format($stats['total_partenaires'], 2)); ?> DH</p>
            </div>
            <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                <i data-lucide="briefcase" class="w-6 h-6"></i>
            </div>
        </div>
        <p class="mt-2 text-xs text-gray-500"><?php echo e($stats['count_partenaires']); ?> transactions</p>
    </div>

    <!-- Dernier paiement client -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
        <div>
    <p class="text-sm font-medium text-gray-500">Dernier paiement client</p>
    <p class="text-lg font-semibold text-gray-900">
        <?php if($lastClient): ?>
            <?php echo e($lastClient->client->surnom ?? 'Inconnu'); ?> — <?php echo e(number_format($lastClient->montant, 2)); ?> DH
        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
</div>

            <div class="p-3 rounded-full bg-green-100 text-green-600">
                <i data-lucide="credit-card" class="w-6 h-6"></i>
            </div>
        </div>
        <p class="mt-2 text-xs text-gray-500">
            <?php if($lastClient): ?>
                <?php echo e($lastClient->date_paiement->diffForHumans()); ?>

            <?php endif; ?>
        </p>
    </div>

    <!-- Dernier paiement partenaire -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
        <div>
    <p class="text-sm font-medium text-gray-500">Dernier paiement partenaire</p>
    <p class="text-lg font-semibold text-gray-900">
        <?php if($lastPartner): ?>
            <?php echo e($lastPartner->partenaire->surnom ?? 'Inconnu'); ?> — <?php echo e(number_format($lastPartner->montant, 2)); ?> DH
        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
</div>

            <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                <i data-lucide="dollar-sign" class="w-6 h-6"></i>
            </div>
        </div>
        <p class="mt-2 text-xs text-gray-500">
            <?php if($lastPartner): ?>
                <?php echo e($lastPartner->date_paiement->diffForHumans()); ?>

            <?php endif; ?>
        </p>
    </div>
</div><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/admin/paiements/partials/_stats.blade.php ENDPATH**/ ?>