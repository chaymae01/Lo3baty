<?php $__env->startSection('content'); ?>
<main class="flex-1 p-8 overflow-y-auto bg-gray-50">
    <div class="max-w-7xl mx-auto space-y-6">

        <h1 class="text-3xl font-extrabold text-indigo-700">🗓 Réservations en attente</h1>

        <?php if(session('ok')): ?>
            <div class="p-3 bg-green-100 text-green-800 rounded shadow-sm">
                <?php echo e(session('ok')); ?>

            </div>
        <?php endif; ?>

        <?php if($reservations->isEmpty()): ?>
            <p class="text-gray-500 text-lg">Aucune réservation en attente.</p>
        <?php else: ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 flex flex-col">
                        <!-- Image -->
                        <img src="<?php echo e($r->annonce->objet->images->first()
                            ? asset('storage/' . $r->annonce->objet->images->first()->url)
                            : 'https://via.placeholder.com/400x250?text=Aucune+image'); ?>"
                            alt="Image de <?php echo e($r->annonce->objet->nom); ?>"
                            class="w-full h-40 object-cover">

                        <!-- Infos -->
                        <div class="p-4 space-y-2 flex-1 flex flex-col justify-between">
                            <div>
                                <h2 class="text-lg font-semibold text-gray-800"><?php echo e($r->annonce->objet->nom); ?></h2>
                                <p class="text-sm text-gray-600">👤 Client : <?php echo e($r->client->prenom); ?> <?php echo e($r->client->nom); ?></p>
                                <p class="text-sm text-gray-600">📅 Du <?php echo e($r->date_debut->format('d/m/Y')); ?> au <?php echo e($r->date_fin->format('d/m/Y')); ?></p>

                                <?php
                                    $start = $r->date_debut;
                                    $end = $r->date_fin;
                                    $days = $start->diffInDays($end) + 1;
                                    $price = $r->annonce->prix_journalier;
                                    $total = $days * $price;
                                ?>

                                <p class="text-sm text-indigo-700 font-medium">
                                    💰 Total : <?php echo e(number_format($total, 2)); ?> MAD (<?php echo e($days); ?> jour<?php echo e($days > 1 ? 's' : ''); ?>)
                                </p>

                                <p class="text-xs text-gray-400">🕐 Demandée le <?php echo e($r->created_at->format('d/m/Y H:i')); ?></p>
                            </div>

                            <!-- Actions -->
                            <div class="flex gap-2 pt-4">
                                <form method="POST" action="<?php echo e(route('partenaire.reservations.valider', $r)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="w-full bg-green-600 text-white px-3 py-2 rounded text-sm hover:bg-green-700 transition">
                                        ✅ Valider
                                    </button>
                                </form>
                                <form method="POST" action="<?php echo e(route('partenaire.reservations.refuser', $r)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="w-full bg-red-600 text-white px-3 py-2 rounded text-sm hover:bg-red-700 transition">
                                        ❌ Refuser
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partenaire', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/partenaire/reservations/index.blade.php ENDPATH**/ ?>