

<?php $__env->startSection('content'); ?>
<main class="flex-1 p-8 overflow-y-auto">
    <div class="max-w-6xl mx-auto bg-white p-6 rounded-xl shadow space-y-6">
        <h1 class="text-2xl font-bold text-indigo-700">🗓 Réservations en attente</h1>

        <?php if(session('ok')): ?>
            <div class="p-3 bg-green-100 text-green-800 rounded"><?php echo e(session('ok')); ?></div>
        <?php endif; ?>

        <?php if($reservations->isEmpty()): ?>
            <p class="text-gray-500">Aucune réservation en attente.</p>
        <?php else: ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray-50 border border-gray-200 rounded-xl p-4 shadow space-y-2">
                        <h2 class="text-lg font-semibold text-gray-800"><?php echo e($r->annonce->objet->nom); ?></h2>
                        <p class="text-sm text-gray-600">Client : <?php echo e($r->client->prenom); ?> <?php echo e($r->client->nom); ?></p>
                        <p class="text-sm text-gray-600">📅 Du <?php echo e($r->date_debut); ?> au <?php echo e($r->date_fin); ?></p>
                        <p class="text-xs text-gray-400">🕐 Demandée le <?php echo e($r->created_at->format('d/m/Y H:i')); ?></p>

                        <div class="flex gap-2 pt-3">
                            <form method="POST" action="<?php echo e(route('reservations.valider', $r)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="bg-green-600 text-white px-3 py-1 text-sm rounded hover:bg-green-700">
                                    ✅ Valider
                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('reservations.refuser', $r)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="bg-red-600 text-white px-3 py-1 text-sm rounded hover:bg-red-700">
                                    ❌ Refuser
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/reservations/index.blade.php ENDPATH**/ ?>