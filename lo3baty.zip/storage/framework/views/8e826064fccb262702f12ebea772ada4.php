<?php echo $__env->make('components.sideBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Finaliser votre réservation</h2>
            
            <!-- Récapitulatif -->
            <div class="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Récapitulatif</h3>
                
                <div class="flex items-center mb-4">
                    <img src="<?php echo e(asset($reservation->annonce->objet->images->first()->url)); ?>" 
                         alt="<?php echo e($reservation->annonce->objet->nom); ?>"
                         class="w-20 h-20 object-cover rounded-lg mr-4">
                    <div>
                        <h4 class="font-medium"><?php echo e($reservation->annonce->objet->nom); ?></h4>
                        <p class="text-sm text-gray-600">
                            <?php echo e($reservation->date_debut->format('d/m/Y')); ?> - 
                            <?php echo e($reservation->date_fin->format('d/m/Y')); ?>

                            (<?php echo e($reservation->date_debut->diffInDays($reservation->date_fin) + 1); ?> jours)
                        </p>
                    </div>
                </div>
                
                <div class="border-t pt-4">
                    <div class="flex justify-between mb-2">
                        <span class="text-gray-600">Prix journalier:</span>
                        <span><?php echo e(number_format($reservation->annonce->prix_journalier, 2)); ?> MAD</span>
                    </div>
                    <div class="flex justify-between mb-2">
                        <span class="text-gray-600">Durée:</span>
                        <span><?php echo e($reservation->date_debut->diffInDays($reservation->date_fin) + 1); ?> jours</span>
                    </div>
                    <div class="border-t my-2"></div>
                    <div class="flex justify-between font-bold text-lg">
                        <span>Total:</span>
                        <span id="totalWithoutDelivery"><?php echo e(number_format($reservation->annonce->prix_journalier * ($reservation->date_debut->diffInDays($reservation->date_fin) + 1), 2)); ?> MAD</span>
                    </div>
                </div>
            </div>
            
            <!-- Formulaire de paiement -->
            <form action="<?php echo e(route('paiement.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Méthode de paiement</h3>
                    
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <input type="radio" id="paypal" name="methode" value="paypal" class="hidden peer" checked>
                            <label for="paypal" class="flex flex-col items-center justify-center p-4 border rounded-lg cursor-pointer peer-checked:border-blue-500 peer-checked:bg-blue-50">
                                <i class="fab fa-paypal text-3xl text-blue-500 mb-2"></i>
                                <span>PayPal</span>
                            </label>
                        </div>
                        <div>
                            <input type="radio" id="especes" name="methode" value="especes" class="hidden peer">
                            <label for="especes" class="flex flex-col items-center justify-center p-4 border rounded-lg cursor-pointer peer-checked:border-blue-500 peer-checked:bg-blue-50">
                                <i class="fas fa-money-bill-wave text-3xl text-green-500 mb-2"></i>
                                <span>Espèces</span>
                            </label>
                        </div>
                        <div>
                            <input type="radio" id="carte" name="methode" value="carte" class="hidden peer">
                            <label for="carte" class="flex flex-col items-center justify-center p-4 border rounded-lg cursor-pointer peer-checked:border-blue-500 peer-checked:bg-blue-50">
                                <i class="fas fa-money-check-alt text-3xl text-purple-500 mb-2"></i>
                                <span>Carte bancaire</span>
                            </label>
                        </div>
                    </div>
                </div>
                
<!-- Option de livraison -->
<div class="mb-6">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">Options de livraison</h3>
    
    <div class="flex items-center mb-4">
        <input type="radio" id="sans_livraison" name="livraison" value="0" class="mr-2" checked>
        <label for="sans_livraison" class="flex-grow">
            <span class="font-medium">Sans livraison</span>
            <p class="text-sm text-gray-600">Vous récupérerez l'objet chez le partenaire</p>
        </label>
    </div>
    
    <div class="flex items-center">
        <input type="radio" id="avec_livraison" name="livraison" value="1" class="mr-2">
        <label for="avec_livraison" class="flex-grow">
            <span class="font-medium">Avec livraison</span>
            <p class="text-sm text-gray-600">Livraison à votre domicile (+20 DH)</p>
        </label>
        <span id="deliveryCost" class="text-gray-600">+20.00 MAD</span>
    </div>
</div>
                
                <!-- Total final -->
                <div class="bg-blue-50 p-4 rounded-lg mb-6">
                    <div class="flex justify-between items-center">
                        <span class="font-bold text-lg">Total à payer:</span>
                        <span id="finalTotal" class="font-bold text-xl text-blue-600">
                            <?php echo e(number_format($reservation->annonce->prix_journalier * ($reservation->date_debut->diffInDays($reservation->date_fin) + 1), 2)); ?> MAD
                        </span>
                    </div>
                </div>
                
                <!-- Boutons -->
                <div class="flex justify-between">
                    <a href="<?php echo e(url()->previous()); ?>" class="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">
                        Retour
                    </a>
                    <button type="submit" class="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition">
                        Confirmer et payer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const basePrice = <?php echo e($reservation->annonce->prix_journalier * ($reservation->date_debut->diffInDays($reservation->date_fin) + 1)); ?>;
        const deliveryRadio = document.getElementById('avec_livraison');
        const noDeliveryRadio = document.getElementById('sans_livraison');
        const finalTotal = document.getElementById('finalTotal');
        const deliveryCost = document.getElementById('deliveryCost');
        
        function updateTotal() {
            if (deliveryRadio.checked) {
                const delivery = 20; // Montant fixe de 20 DH
                finalTotal.textContent = (basePrice + delivery).toFixed(2) + ' MAD';
                deliveryCost.textContent = '+20.00 MAD'; // Texte fixe
            } else {
                finalTotal.textContent = basePrice.toFixed(2) + ' MAD';
            }
        }
        
        deliveryRadio.addEventListener('change', updateTotal);
        noDeliveryRadio.addEventListener('change', updateTotal);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/client/paiement.blade.php ENDPATH**/ ?>