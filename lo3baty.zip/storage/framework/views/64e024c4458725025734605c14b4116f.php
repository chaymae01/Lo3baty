<svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" stroke-width="2"
     viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round"
          d="M8 7V3m8 4V3M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
</svg>
<?php /**PATH C:\wamp64\www\laravelWeb\resources\views/components/icons/calendar.blade.php ENDPATH**/ ?>