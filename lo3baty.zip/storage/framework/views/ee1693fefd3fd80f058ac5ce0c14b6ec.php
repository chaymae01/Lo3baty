

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h1 class="text-2xl font-semibold">Dashboard Partenaire</h1>
        
        <p class="text-gray-500 mt-4">Bienvenue dans votre espace partenaire !</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/partner/dashboard.blade.php ENDPATH**/ ?>