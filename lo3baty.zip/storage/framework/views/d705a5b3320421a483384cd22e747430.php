<h1>Bonjour <?php echo e($client->nom ?? ''); ?> <?php echo e($client->prenom ?? ''); ?>,</h1>

<p>Merci d'avoir utilisé notre service de location de jouets <strong>Lo3baty</strong> !</p>

<p>Nous vous confirmons que votre réservation <strong>#<?php echo e($reservation->id); ?></strong> est <span style="color: green; font-weight: bold;">terminée avec succès</span>.</p>

<hr>

<h2>Détails de votre réservation</h2>

<ul>
    <li><strong>Jouet réservé :</strong> <?php echo e($objet->nom ?? 'un jouet'); ?></li>
    <li><strong>Durée :</strong> 
        du <?php echo e(\Carbon\Carbon::parse($reservation->date_debut)->format('d/m/Y')); ?> 
        au <?php echo e(\Carbon\Carbon::parse($reservation->date_fin)->format('d/m/Y')); ?>

    </li>
    <?php if(isset($annonce->prix_journalier)): ?>
    <li><strong>Montant total :</strong> <?php echo e($annonce->prix_journalier * abs(\Carbon\Carbon::parse($reservation->date_debut)->diffInDays(\Carbon\Carbon::parse($reservation->date_fin)) + 1)); ?> DH</li>
<?php endif; ?>

    <?php if(isset($objet->categorie)): ?>
        <li><strong>Catégorie :</strong> <?php echo e($objet->categorie->nom); ?></li>
    <?php endif; ?>
</ul>

<hr>

<h2>Votre avis compte !</h2>

<p>
    Pour nous aider à améliorer nos services, nous vous invitons à évaluer votre expérience de location.
    Cela ne prend que quelques secondes !
</p>

<p>
<a href="http://127.0.0.1:8000/evaluation_annonce/<?php echo e($reservation->id); ?>">
    Donnez votre avis
</a>

</p>

<hr>

<h2>Et après ?</h2>
<ul>
    <li>Assurez-vous que le jouet est bien retourné dans le même état qu'à la réception.</li>
    <li>Un reçu officiel de location est disponible sur votre compte.</li>
    <li>Besoin d’aide ? Contactez notre équipe ci-dessous.</li>
</ul>

<p>
    📧 <strong>Support :</strong> <a href="mailto:support@lo3baty.com">support@lo3baty.com</a><br>
    📞 <strong>Téléphone :</strong> +212 6 12 34 56 78
</p>

<br>

<p>
    Merci encore pour votre confiance, et à très bientôt sur <strong>Lo3baty</strong> !<br>
    — L'équipe <strong>Lo3baty</strong>
</p>

<p>
    <img src="<?php echo e(asset('images/Lo3baty.jpg')); ?>" alt="Lo3baty Logo" width="150">
</p>
<?php /**PATH C:\wamp64\www\laravelWeb\resources\views/client/evaluation_email.blade.php ENDPATH**/ ?>