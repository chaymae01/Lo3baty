<?php $__env->startSection('title', 'Détails Annonce'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">
    <!-- Sidebar fixe à gauche -->
    <div class="w-64 fixed top-0 left-0 bottom-0 bg-white shadow-md z-10">
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Contenu principal avec marge pour la sidebar -->
    <div class="flex-1 p-8 space-y-10 ml-64"> <!-- Ajustez ml-64 selon la largeur de votre sidebar -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Détails de l'annonce #<?php echo e($annonce->id); ?></h1>
        <a href="<?php echo e(route('admin.annonces.index')); ?>" class="text-blue-600 hover:text-blue-900">
            ← Retour
        </a>
    </div>

    <div class="bg-white shadow-md rounded-lg p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <h2 class="text-lg font-semibold mb-2">Informations de base</h2>
                <p>
                    <span class="font-medium">Statut:</span> 
                    <span class="px-2 py-1 text-xs rounded-full 
                        <?php echo e($annonce->statut === 'active' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'); ?>">
                        <?php echo e(ucfirst($annonce->statut)); ?>

                    </span>
                </p>
                <p><span class="font-medium">Prix journalier:</span> <?php echo e(number_format($annonce->prix_journalier, 2)); ?> €</p>
                <p><span class="font-medium">Adresse:</span> <?php echo e($annonce->adresse); ?></p>
            </div>
            <div>
                <h2 class="text-lg font-semibold mb-2">Dates</h2>
                <p><span class="font-medium">Publication:</span> <?php echo e($annonce->date_publication->format('d/m/Y')); ?></p>
                <p><span class="font-medium">Disponibilité:</span> 
                    <?php echo e($annonce->date_debut->format('d/m/Y')); ?> - <?php echo e($annonce->date_fin->format('d/m/Y')); ?>

                </p>
                <?php if($annonce->premium): ?>
                <p><span class="font-medium">Premium:</span> 
                    <?php echo e($annonce->premium_periode); ?> jours (début: <?php echo e($annonce->premium_start_date->format('d/m/Y')); ?>)
                </p>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <h2 class="text-lg font-semibold mb-2">Objet</h2>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p class="font-medium"><?php echo e($annonce->objet->nom ?? 'Non spécifié'); ?></p>
                    <p class="text-sm text-gray-600 mt-1"><?php echo e($annonce->objet->description ?? ''); ?></p>
                </div>
            </div>
            <div>
                <h2 class="text-lg font-semibold mb-2">Partenaire (DEBUG)</h2>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p class="font-medium">ID Partenaire: <?php echo e($annonce->partenaire_id); ?></p>
                    <p class="font-medium">Nom: <?php echo e($annonce->partenaire ? $annonce->partenaire->name : 'NULL'); ?></p>
                    <p class="text-sm text-gray-600 mt-1">Email: <?php echo e($annonce->partenaire->email ?? 'NULL'); ?></p>
                    <?php if($annonce->partenaire): ?>
                        <p class="text-sm text-gray-600 mt-1">Type: <?php echo e(get_class($annonce->partenaire)); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/Admin/annonces/show.blade.php ENDPATH**/ ?>