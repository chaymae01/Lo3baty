<?php $__env->startSection('content'); ?>
<main class="flex-1 p-8 overflow-y-auto bg-gray-50">
    <div class="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow space-y-6">
        <h1 class="text-2xl font-bold text-indigo-700 mb-4">
            ✍️ Évaluer le client (Réservation ID : <?php echo e($reservation->id); ?>)
        </h1>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 p-3 rounded mb-4">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('partenaire.evaluations.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="reservation_id" value="<?php echo e($reservation->id); ?>">

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Note (1 à 5)</label>
                <select name="note" class="w-full border rounded px-3 py-2">
                    <option value="">-- Choisir --</option>
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?> ⭐</option>
                    <?php endfor; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Commentaire (optionnel)</label>
                <textarea name="commentaire" class="w-full border rounded px-3 py-2" rows="4"></textarea>
            </div>

            <button class="bg-indigo-600 text-white px-6 py-2 rounded shadow hover:bg-indigo-700 transition">
                ✅ Soumettre l'évaluation
            </button>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partenaire', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/partenaire/evaluations/create.blade.php ENDPATH**/ ?>