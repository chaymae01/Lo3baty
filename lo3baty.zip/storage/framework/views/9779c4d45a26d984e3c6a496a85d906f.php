<?php $__env->startSection('title', 'Gestion des Réservations'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex">
    <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex-1 p-6 space-y-6">
        <div class="container mx-auto px-4 py-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Gestion des Réservations</h1>
            </div>

            
            <div class="mb-6 bg-white p-4 rounded-lg shadow">
                <form method="GET" action="<?php echo e(route('admin.reservations.index')); ?>" class="flex items-center space-x-4">
                    <label for="statut" class="text-sm font-medium text-gray-700">Filtrer par statut :</label>
                    <select name="statut" id="statut" onchange="this.form.submit()" 
                            class="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Tous les statuts</option>
                        <?php $__currentLoopData = $statuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($statut); ?>" <?php echo e(request('statut') == $statut ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst(str_replace('_', ' ', $statut))); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if(request('statut')): ?>
                        <a href="<?php echo e(route('admin.reservations.index')); ?>" 
                           class="text-sm text-gray-600 hover:text-gray-800 ml-2">
                            Réinitialiser
                        </a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">ID</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Client</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Annonce</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Dates</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Statut</th>
                                <th class="py-3 px-4 border-b border-gray-200 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-3 px-4 border-b border-gray-200"><?php echo e($reservation->id); ?></td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php echo e($reservation->client->nom ?? 'Client inconnu'); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php echo e($reservation->annonce->id ?? 'Annonce supprimée'); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php echo e($reservation->date_debut->format('d/m/Y')); ?> - 
                                    <?php echo e($reservation->date_fin->format('d/m/Y')); ?>

                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <?php
                                       $badgeClasses = [
    'en_attente' => 'bg-yellow-100 text-yellow-800',
    'confirmée' => 'bg-green-100 text-green-800',
    'refusée' => 'bg-red-100 text-red-800'
];

                                    ?>
                                    <span class="px-2 py-1 text-xs rounded-full <?php echo e($badgeClasses[$reservation->statut]); ?>">
                                        <?php echo e(ucfirst(str_replace('_', ' ', $reservation->statut))); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-4 border-b border-gray-200">
                                    <a href="<?php echo e(route('admin.reservations.show', $reservation)); ?>" 
                                       class="text-blue-600 hover:text-blue-900">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-4 px-6 py-3 bg-gray-50 border-t border-gray-200">
                    <?php if(request('statut')): ?>
                        <?php echo e($reservations->appends(['statut' => request('statut')])->links()); ?>

                    <?php else: ?>
                        <?php echo e($reservations->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\laravelWeb\resources\views/Admin/reservations/index.blade.php ENDPATH**/ ?>