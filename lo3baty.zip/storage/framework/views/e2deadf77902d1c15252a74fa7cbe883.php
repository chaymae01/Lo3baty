<svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" stroke-width="2"
     viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round"
          d="M15 11V5l-6 2H5v10h4l6 2v-6h2l4 4v-8l-4 4h-2z"/>
</svg>
<?php /**PATH C:\wamp64\www\laravelWeb\resources\views/components/icons/megaphone.blade.php ENDPATH**/ ?>